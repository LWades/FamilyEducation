<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Index</title>
</head>
<body>
<a href="<?php echo U('Home/Index/homePage');?>">主页</a>
</body>
</html>